export interface Pet {    
    name: string;
}
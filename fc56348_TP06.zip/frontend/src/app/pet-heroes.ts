import { Pet } from './pet';

export const PETS: Pet[] = [
  { name: 'Max' },
  { name: 'Sushi' },
  { name: 'Thor' },
  { name: 'Billy' },
  { name: 'Luna' },
  { name: 'Bart' },
  { name: 'Jolie' },
  { name: 'Yogi' },
  { name: 'Smarty' }
];
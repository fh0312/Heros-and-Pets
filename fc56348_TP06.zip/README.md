
# TP6 - MEAN Stack 
# - Solução implementada do guião do exercício sobre MEAN


@author
- Francisco Henriques - FC56348

 
Para instalar e executar a solução implementada proceder do seguinte modo:

# INSTALAR

    1. Decarregar o ficheiro zip e extrair conteudo.
    2. Dentro da pasta backend instalar os node-modules executando o comando:
        > npm install
    3. Fazer o mesmo na pasta frontend

# EXECUTAR

    4. Inicializar o backend depois dos modulos terem sido instalados, executando na pasta "backend/" o comando: 
        > node bin/www
    5. Inicialiazar o frontend depois dos modulos terem sido instalados, executando na pasta "frontend/" o comando: 
        > ng serve --open

    6. A aplicação web será inicializada com o frontend no localhost:3000 e o backend no localhost:4200 por default.
